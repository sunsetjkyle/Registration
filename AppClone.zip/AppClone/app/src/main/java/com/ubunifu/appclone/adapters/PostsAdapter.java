package com.ubunifu.appclone.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.ubunifu.appclone.CommentsActivity;
import com.ubunifu.appclone.R;
import com.ubunifu.appclone.models.Posts;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class PostsAdapter extends RecyclerView.Adapter<PostsAdapter.ViewHolder> {

    Context mContext;
    ArrayList<Posts> mPostsArrayList;

    public PostsAdapter(Context mContext, ArrayList<Posts> mPostsArrayList) {
        this.mContext = mContext;
        this.mPostsArrayList = mPostsArrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(mContext).inflate(R.layout.posts_item_list, parent, false);

        return new PostsAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        //get values from firestore db for every position

        Posts posts = mPostsArrayList.get(position);
        holder.caption.setText(posts.getCaption());
        holder.name.setText(posts.getFull_names());
        Glide.with(mContext).load(mPostsArrayList.get(position).getPost_img_url()).into(holder.postImage);
        Glide.with(mContext).load(mPostsArrayList.get(position).getProfile_img_url()).into(holder.profImg);


        // to comment activity

        holder.commentImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext, CommentsActivity.class);
                intent.putExtra("postId", posts.getPost_id());
                intent.putExtra("publisherId", posts.getPublisher());
//                Toast.makeText(mContext, "PostId = " + posts.getPost_id() + "Publisher is " + posts.getPublisher(), Toast.LENGTH_LONG).show();
                mContext.startActivity(intent);

            }
        });

    }

    @Override
    public int getItemCount() {
        return mPostsArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        //Declare your views

        TextView caption, name;
        ImageView postImage, commentImg, saveImg, likeImg, imgMore;
        CircleImageView profImg;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            //initialize views

            caption = itemView.findViewById(R.id.description);
            postImage = itemView.findViewById(R.id.post_image);
            commentImg = itemView.findViewById(R.id.comment);
            saveImg = itemView.findViewById(R.id.save);
            likeImg = itemView.findViewById(R.id.like);
            name = itemView.findViewById(R.id.username);
            profImg = itemView.findViewById(R.id.image_profile);
            imgMore = itemView.findViewById(R.id.more);



        }
    }
}
